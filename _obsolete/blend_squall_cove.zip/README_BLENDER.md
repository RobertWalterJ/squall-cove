# Squall Cove Blender files

Editable Blender 4.2 scenes for every Squall Cove model. Open them in Blender 4.2 or newer.

| File | Contents |
|---|---|
| `squall_cove_game_models.blend` | exactly what the game loads: the fleet, harbour, nature, cargo and the Canadian Coast Guard boats (`assets/*.glb.b64.txt` are these, base64 encoded) |
| `squall_cove_kit_watercraft.blend` | dinghy, dory, gaff cutter, keelboat, tug and workboat in four styles each |
| `squall_cove_kit_harbour.blend` | piers, bollards, buoys, channel markers and lighthouses |
| `squall_cove_kit_cargo.blend` | barrels, crates, drums, sacks, rope, ice, ingot pallets |
| `squall_cove_kit_containers.blend` | 10, 20 and 40 foot containers |
| `squall_cove_kit_rocks.blend` | boulders, pebbles, sea stacks and slabs |
| `squall_cove_kit_vegetation.blend` | broadleaf, pine and palm trees, shrubs and grass |

## Notes

- **Terrain and sky are not here.** The game builds its island from `assets/terrain_257.f32.b64.txt` and uses `assets/sky_2k.jpg`. The terrain generator is `generators/build_terrain.py`.
- **Where the models come from.**
  - `generators/` holds the Python scripts that build every model: `pg_*.py` are the model libraries and `build_*.py` and `export_*.py` the batch builders.
  - Those scripts are the source of truth. Hand edits made in these .blend files stay in the files; to keep one, re-export the GLB, or change the generator and rebuild.
- **Frames.** Scenes are Z up. glTF export with "+Y Up" gives the game's frame.
